<?php
// agendamento_concluir.php
// Endpoint AJAX (POST) chamado pelo modal "Concluir Agendamento" em
// Agendamentos/paginas/agendar.php.
//
// Recebe, al�m do agendamento, a(s) forma(s) de pagamento (mesmo
// componente usado em Financeiro > Cadastrar Baixa) e a flag "fiado".
// Marca o agendamento como conclu�do (o registro nunca � apagado � fica
// no banco com Status = 'concluido' para hist�rico) e cria automaticamente
// o lan�amento financeiro correspondente:
//   - fiado = 0 -> lan�amento PAGO, entra normalmente nas receitas.
//   - fiado = 1 -> lan�amento PENDENTE, fica fora do c�lculo de receitas
//                  at� ser recebido em Financeiro > Fiados.
// O hor�rio volta a ficar dispon�vel na grade, igual ao cancelamento.
//
// Agendamento duplicado (dois hor�rios vinculados por grupo_agendamento):
// concluir QUALQUER UMA das duas linhas (a principal ou a secund�ria)
// conclui as DUAS automaticamente, de forma sim�trica. O lan�amento
// financeiro � criado UMA �NICA VEZ, sempre a partir da linha PRINCIPAL
// (que carrega o valor cobrado � 1x ou 2x o servi�o); a linha secund�ria
// s� � marcada como conclu�da e tem seu hor�rio liberado, sem gerar
// nenhum lan�amento pr�prio (evita duplicidade no financeiro). Pra
// concluir S� UM dos dois hor�rios (deixando o outro em aberto), ver
// agendamento_concluir_individual.php.
//
// Servi�o realmente realizado: o modal "Concluir Agendamento" deixa o
// barbeiro escolher, num SELECT alimentado pelos servi�os cadastrados no
// banco, qual servi�o foi de fato prestado � pode ser diferente do que foi
// originalmente agendado (ex.: agendou "Corte + Barba" mas s� fez
// "Corte"). Isso vale TANTO pra agendamento avulso quanto pra duplicado:
//   - avulso: um �nico campo, idServicoRealizado.
//   - duplicado: DOIS campos independentes � idServicoRealizado (Hor�rio
//     1/principal) e idServicoRealizadoSecundario (Hor�rio 2/secund�rio)
//     � cobre o caso de "o pai vai com o filho e corta outro corte do j�
//     agendado", em que cada pessoa pode ter feito um corte diferente do
//     que constava no agendamento original. O valor final cobrado (no
//     lan�amento �nico, sempre pela linha principal) � recalculado a
//     partir dos servi�os efetivamente escolhidos: s� o do Hor�rio 1
//     (cobranca_duplicado = 'um') ou a soma dos dois (cobranca_duplicado
//     = 'dois') � mesma regra de cobran�a j� definida na cria��o do
//     agendamento, s� que agora aplicada aos servi�os REALMENTE feitos.
// Quando informado, o Agendamento � atualizado (idServico + Valor) ANTES
// de gerar o lan�amento financeiro, ent�o tudo que l� a partir da�
// (financeiro, hist�rico do cliente, relat�rios) j� reflete s� o que foi
// realmente cobrado.
//
// "Cliente Ausente" (ausente = 1): o cliente n�o veio. O hor�rio �
// liberado exatamente como numa conclus�o normal (grade mostra "Ausente -
// Nome do Cliente" em vez de "Conclu�do - Nome"), mas N�O � gerado nenhum
// lan�amento financeiro (n�o houve cobran�a) � nem pago, nem fiado. Forma
// de pagamento e "fiado" s�o ignorados nesse caso. Agendamento duplicado
// segue a mesma regra sim�trica: marcar qualquer uma das duas linhas como
// ausente marca as duas, sem gerar lan�amento nenhum.

require_once __DIR__ . '/../../includes/session.php';
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../includes/guard.php';
exigirSessao(['barbeiro'], json: true);

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/FinanceiroService.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'erro' => 'M�todo n�o permitido.']);
    exit;
}

$idBarbeiro                    = (int) $_SESSION['id'];
$idAgendamento                 = (int) ($_POST['idAgendamento'] ?? 0);
$ausente                       = !empty($_POST['ausente']);
$fiado                         = !$ausente && !empty($_POST['fiado']);
$formasBrutas                  = $_POST['formas'] ?? [];
$formasBrutas                  = is_array($formasBrutas) ? $formasBrutas : [];
$idServicoRealizado            = (int) ($_POST['idServicoRealizado'] ?? 0);
$idServicoRealizadoSecundario  = (int) ($_POST['idServicoRealizadoSecundario'] ?? 0);

if ($idAgendamento <= 0) {
    echo json_encode(['ok' => false, 'erro' => 'Agendamento inv�lido.']);
    exit;
}

$formas = FinanceiroService::normalizarFormasPagamento($formasBrutas);

// Forma de pagamento s� � obrigat�ria quando N�O � fiado e N�O � "Cliente
// Ausente" � no fiado ela fica bloqueada no formul�rio e s� � definida no
// recebimento (Financeiro > Fiados); no ausente n�o existe cobran�a
// nenhuma, ent�o n�o faz sentido pedir forma de pagamento.
if (!$ausente && !$fiado && empty($formas)) {
    echo json_encode(['ok' => false, 'erro' => 'Selecione ao menos uma forma de pagamento.']);
    exit;
}

$stmt = $pdo->prepare(
    "SELECT a.idAgendamento, a.idHorario, a.idCliente, a.idServico, a.Valor, a.Status,
            a.grupo_agendamento, a.eh_principal_agendamento, a.cobranca_duplicado,
            c.nome AS clienteNome, s.nome AS servicoNome
     FROM Agendamentos a
     INNER JOIN Horario h ON h.idHorario = a.idHorario
     INNER JOIN Cliente c ON c.idCliente = a.idCliente
     INNER JOIN Servico s ON s.idServico = a.idServico
     WHERE a.idAgendamento = :id AND h.id_barbeiro = :b AND a.Status <> 'cancelado'"
);
$stmt->execute(['id' => $idAgendamento, 'b' => $idBarbeiro]);
$agendamento = $stmt->fetch();

if (!$agendamento) {
    echo json_encode(['ok' => false, 'erro' => 'Agendamento n�o encontrado.']);
    exit;
}

if ($agendamento['Status'] === 'concluido') {
    echo json_encode(['ok' => false, 'erro' => 'Esse agendamento j� est� conclu�do.']);
    exit;
}

if ($agendamento['Status'] === 'ausente') {
    echo json_encode(['ok' => false, 'erro' => 'Esse agendamento j� foi marcado como Cliente Ausente.']);
    exit;
}

/**
 * Busca um servi�o ATIVO pelo id. Usada tanto pro servi�o do Hor�rio 1
 * quanto do Hor�rio 2 � mesma valida��o nos dois casos.
 */
function buscarServicoAtivo(PDO $pdo, int $idServico): ?array
{
    if ($idServico <= 0) {
        return null;
    }
    $stmt = $pdo->prepare('SELECT idServico, nome, valor FROM Servico WHERE idServico = :s AND ativo = 1');
    $stmt->execute(['s' => $idServico]);
    $servico = $stmt->fetch();
    return $servico ?: null;
}

try {
    $pdo->beginTransaction();

    // ---------- Agendamento duplicado: descobre a linha irm� (se houver) ----------
    // Sempre roteia o lan�amento financeiro pela linha PRINCIPAL, n�o
    // importa qual das duas o barbeiro clicou.
    $agendamentoPrincipal  = $agendamento;
    $agendamentoSecundario = null;

    if ($agendamento['grupo_agendamento'] !== null) {
        $stmtIrmao = $pdo->prepare(
            "SELECT a.idAgendamento, a.idHorario, a.idCliente, a.idServico, a.Valor, a.Status,
                    a.eh_principal_agendamento, a.cobranca_duplicado, c.nome AS clienteNome, s.nome AS servicoNome
             FROM Agendamentos a
             INNER JOIN Horario h ON h.idHorario = a.idHorario
             INNER JOIN Cliente c ON c.idCliente = a.idCliente
             INNER JOIN Servico s ON s.idServico = a.idServico
             WHERE a.grupo_agendamento = :g AND a.idAgendamento <> :id AND h.id_barbeiro = :b AND a.Status <> 'cancelado'
             FOR UPDATE"
        );
        $stmtIrmao->execute(['g' => $agendamento['grupo_agendamento'], 'id' => $agendamento['idAgendamento'], 'b' => $idBarbeiro]);
        $irmao = $stmtIrmao->fetch();

        if ($irmao) {
            if ((bool) $agendamento['eh_principal_agendamento']) {
                $agendamentoPrincipal  = $agendamento;
                $agendamentoSecundario = $irmao;
            } else {
                $agendamentoPrincipal  = $irmao;
                $agendamentoSecundario = $agendamento;
            }
        }
    }

    // ---------- Servi�o realmente realizado (SELECT do modal Concluir) ----------
    // Vale tanto pra agendamento avulso quanto pra duplicado (ver
    // cabe�alho do arquivo) � a �nica diferen�a � que o duplicado tem DOIS
    // campos independentes, um por hor�rio.
    if (!$ausente) {
        if ($idServicoRealizado > 0) {
            $servicoRealizadoPrincipal = buscarServicoAtivo($pdo, $idServicoRealizado);
            if (!$servicoRealizadoPrincipal) {
                $pdo->rollBack();
                echo json_encode(['ok' => false, 'erro' => 'Servi�o selecionado para o Hor�rio 1 � inv�lido ou est� inativo.']);
                exit;
            }

            $stmtAtualizaServico = $pdo->prepare('UPDATE Agendamentos SET idServico = :s, Valor = :v WHERE idAgendamento = :id');
            $stmtAtualizaServico->execute([
                's'  => $servicoRealizadoPrincipal['idServico'],
                'v'  => $servicoRealizadoPrincipal['valor'],
                'id' => $agendamentoPrincipal['idAgendamento'],
            ]);

            $agendamentoPrincipal['idServico']   = (int) $servicoRealizadoPrincipal['idServico'];
            $agendamentoPrincipal['servicoNome'] = $servicoRealizadoPrincipal['nome'];
            $agendamentoPrincipal['Valor']       = (float) $servicoRealizadoPrincipal['valor'];
        }

        if ($agendamentoSecundario && $idServicoRealizadoSecundario > 0) {
            $servicoRealizadoSecundario = buscarServicoAtivo($pdo, $idServicoRealizadoSecundario);
            if (!$servicoRealizadoSecundario) {
                $pdo->rollBack();
                echo json_encode(['ok' => false, 'erro' => 'Servi�o selecionado para o Hor�rio 2 � inv�lido ou est� inativo.']);
                exit;
            }

            $stmtAtualizaServicoSecundario = $pdo->prepare('UPDATE Agendamentos SET idServico = :s WHERE idAgendamento = :id');
            $stmtAtualizaServicoSecundario->execute([
                's'  => $servicoRealizadoSecundario['idServico'],
                'id' => $agendamentoSecundario['idAgendamento'],
            ]);

            $agendamentoSecundario['idServico']   = (int) $servicoRealizadoSecundario['idServico'];
            $agendamentoSecundario['servicoNome'] = $servicoRealizadoSecundario['nome'];
            $agendamentoSecundario['Valor']       = (float) $servicoRealizadoSecundario['valor'];
        }

        // Recalcula o valor cobrado (sempre pela linha principal) a partir
        // dos servi�os REALMENTE selecionados acima � nunca do que foi s�
        // agendado. Mesma regra de cobranca_duplicado j� definida na
        // cria��o: 'um' cobra s� o Hor�rio 1; 'dois' soma os dois.
        if ($agendamentoSecundario) {
            $novoValorPrincipal = $agendamentoPrincipal['Valor'];
            if (($agendamentoPrincipal['cobranca_duplicado'] ?? null) === 'dois') {
                $novoValorPrincipal += $agendamentoSecundario['Valor'];
            }

            if ($novoValorPrincipal !== $agendamentoPrincipal['Valor']) {
                $stmtAtualizaValorPrincipal = $pdo->prepare('UPDATE Agendamentos SET Valor = :v WHERE idAgendamento = :id');
                $stmtAtualizaValorPrincipal->execute(['v' => $novoValorPrincipal, 'id' => $agendamentoPrincipal['idAgendamento']]);
            }
            $agendamentoPrincipal['Valor'] = $novoValorPrincipal;
        }
    }

    if ($ausente) {
        // ---------- Cliente Ausente: libera o hor�rio, N�O gera lan�amento ----------
        FinanceiroService::marcarAgendamentoAusente($pdo, $agendamentoPrincipal);

        if ($agendamentoSecundario) {
            FinanceiroService::marcarAgendamentoAusente($pdo, $agendamentoSecundario);
        }

        $idLancamento = null;
    } else {
        // Nome do servi�o do hor�rio secund�rio (se houver) � usado para o
        // lan�amento/fiado exibir os DOIS cortes quando os dois foram cobrados
        // (cobranca_duplicado = 'dois'), e s� o principal quando foi cobrado
        // apenas um (ver FinanceiroService::concluirAgendamentoComPagamento).
        $agendamentoPrincipal['servicoSecundarioNome'] = $agendamentoSecundario['servicoNome'] ?? null;

        // �nico lan�amento financeiro do atendimento, sempre com o valor da
        // linha principal (1x ou 2x o servi�o, j� recalculado acima a
        // partir do que foi realmente escolhido).
        $idLancamento = FinanceiroService::concluirAgendamentoComPagamento($pdo, $agendamentoPrincipal, $formas, $fiado, $idBarbeiro);

        // Conclui tamb�m a linha secund�ria (sem gerar nenhum lan�amento
        // pr�prio) e libera o hor�rio dela � mesmo comportamento sim�trico
        // visto pelo barbeiro em qualquer uma das duas linhas.
        if ($agendamentoSecundario) {
            $stmtConcluiSecundario = $pdo->prepare("UPDATE Agendamentos SET Status = 'concluido' WHERE idAgendamento = :id");
            $stmtConcluiSecundario->execute(['id' => $agendamentoSecundario['idAgendamento']]);

            $stmtLiberaSecundario = $pdo->prepare('UPDATE Horario SET disponivel = 1 WHERE idHorario = :h');
            $stmtLiberaSecundario->execute(['h' => $agendamentoSecundario['idHorario']]);
        }
    }

    $pdo->commit();

    $camposLog = [
        ['name' => '?? Agendamento', 'value' => '#' . $agendamentoPrincipal['idAgendamento'], 'inline' => true],
        ['name' => '?? Cliente', 'value' => $agendamentoPrincipal['clienteNome'], 'inline' => true],
        ['name' => '?? Servi�o', 'value' => $agendamentoPrincipal['servicoNome'], 'inline' => true],
        ['name' => '?? Status financeiro', 'value' => $ausente ? 'Cliente ausente (sem cobran�a)' : ($fiado ? 'Fiado (pendente)' : 'Pago'), 'inline' => true],
    ];

    if ($agendamentoSecundario) {
        $camposLog[] = ['name' => '?? Duplicado', 'value' => ($ausente ? 'Marcado como ausente junto com #' : 'Conclu�do junto com #') . $agendamentoSecundario['idAgendamento'] . ' (' . $agendamentoSecundario['servicoNome'] . ')', 'inline' => true];
    }

    DiscordLogger::agendamentos(
        $ausente ? '?? Cliente ausente' : '? Agendamento conclu�do',
        $camposLog,
        $ausente ? DiscordLogger::COR_ALERTA : DiscordLogger::COR_SUCESSO
    );

    echo json_encode([
        'ok'                      => true,
        'idLancamento'            => $idLancamento,
        'fiado'                   => $fiado,
        'ausente'                 => $ausente,
        'idAgendamentoSecundario' => $agendamentoSecundario['idAgendamento'] ?? null,
    ]);
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    DiscordLogger::erro('?? Falha ao concluir agendamento', $e);
    http_response_code(500);
    echo json_encode(['ok' => false, 'erro' => 'Erro ao concluir o agendamento.']);
}